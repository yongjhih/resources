
--[[

    Resource:   bank (written by 50p)
    Version:    2.2
    
    Filename:   bank.events.lua

]]

--#region New custom events
addEvent( "onPlayerWithdrawMoney" );
addEvent( "onPlayerDepositMoney" );
addEvent( "onPlayerTransferMoney" );
addEvent( "onPlayerEnterBank" );
addEvent( "onPlayerEnterBankInterior" );
addEvent( "onPlayerLeaveBank" );
addEvent( "onPlayerLeaveBankInterior" );
--#endregion
