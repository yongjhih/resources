rootElement = getRootElement()
thisResource = getThisResource()
thisResourceRoot = getResourceRootElement(thisResource)
thisDynamicRoot = getResourceDynamicElementRoot(thisResource)